<?php

class LanguageController extends BaseController {

	/**
	 * Change a language of the application.
	 *
	 * @return Response
	 */
	public function change($lang)
	{
		//
	}
}